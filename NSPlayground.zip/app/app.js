const Vue = require("nativescript-vue");

new Vue({
  data() {
    return {
      completed: [],
      textFieldValue: "",
      todos: [],
    }
  },
  methods: {
    onItemTap: function (args) {
      console.log('Item with index: ' + args.index + ' tapped');
    },
    onButtonTap() {
      console.log(this.textFieldValue)
      this.todos.unshift({ name: this.textFieldValue });
      this.textFieldValue = "";

    },
  },


  template: `
    <Page class="page">
      <ActionBar title="hello" class="action-bar" />
     

        <StackLayout class="home-panel">
 
<TabView height="100%">
  <TabViewItem title="To Do">
 
<StackLayout orientation="vertical" width="100%" height="100%">
       <GridLayout columns="2*,*" rows="auto" width="100%">
<Button row="0" col="1" text="Button" @tap="onButtonTap" />
<TextField row="0" col="0" v-model="textFieldValue" hint="Enter text..." />
</GridLayout>
<ListView for="todo in todos" @itemTap="onItemTap" height="100%">
  <v-template>
      <Label :text="todo.name" />

  </v-template>
</ListView>

</StackLayout>
  </TabViewItem>
  <TabViewItem title="Completed">
  
<ListView class="list-group" for="country in countries" @itemTap="onItemTap" style="height:1250px">
  <v-template>
  <Label :text="todo.name" />
  </v-template>
</ListView>
  </TabViewItem>
</TabView>
        <Button text="Log it!" @tap="onButtonTap" />
          <!--Add your page content here-->
<Label text="Label" />

        </StackLayout>
    
    </Page>
  `,

}).$start();